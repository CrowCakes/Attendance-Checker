--------------------------------------------------------------------------------
DefaultIcon ver 2.0
Available for download at
http://www.defaulticon.com
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
  INTERACTIVEMANIA
  Copyright (c) � 2010-2011 Apostolos Paschalidis interactivemania
  All Rights Reserved.
  http://www.interactivemania.com

  NOTICE: interactivemania permits you to use, modify, and distribute this file
  in accordance with the terms of the license agreement mentioned in the section 
  "COPYRIGHT NOTICE" below.
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Release History
===============


ver 2.0
===========
653 icons in total
------------------

-- 653 icons added 2011 Sep 09 ver 2.0




ver 1.0
===========
173 Icons in total

-- 37 icons added 2010 Sep 10 ver 1.0
-- 26 icons added 2010 Jul 02 ver 0.4
-- 26 icons added 2010 May 26 ver 0.3
-- 26 icons added 2010 Apr 26 ver 0.2
-- 05 icons added 2010 Mar 24 ver 0.11
-- 53 icons added 2010 Mar 18 ver 0.10
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Available Formats
=================
-- .eps
-- .png (16x16, 32x32, 64x64, 128x128, 256x256) black
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
COPYRIGHT NOTICE:
=================
Anyone downloading and/or using DefaultIcon agrees to the following terms:

License
=======
The license under which DefaultIcon is released is licensed under a Creative 
Commons Attribution-No Derivative Works 3.0. More can be found
at http://creativecommons.org/licenses/by-nd/3.0/ .
In short terms:
this license allows for redistribution, commercial and non-commercial, as long 
as it is passed along unchanged and in whole, with credit to interactivemania
(with link http://www.interactivemania.com)


License Clarification:


You may use any part of the set:

> in digital format on websites UI, multimedia presentations, broadcast film and video,  mobile applications, desktop applications, theme design,
> in printed promotional materials, magazines, newspapers, books, brochures, flyers, CD/DVD covers,

commercial or not, without any further clarification from interactivemania, with only obligation to attribute interactivemania, (i.e. in the credits project).

*** You can use it in a commercial  theme, as long as the license, and this readme file accompanying the set is included in your deliverables. ***


You may not use the set:

> For pornographic, unlawful or other immoral purposes, for spreading hate or discrimination, or to defame or victimise other people, sociteties, cultures.
>To endorse products and services if it depicts a person.
> In a way that can give a bad name to interactivemania or DefaultIcon.
> As part of a trademark, service mark or logo.
> SELLING AND REDISTRIBUTION OF THE ICON SET (INDIVIDUALLY OR ALONG WITH OTHER ICON SETS) IS STRICTLY FORBIDDEN!

The No-Derivatives directive forbids you to build a new icon-set, upon DefaultIcon. It doesn't forbids you to build any of the afformentioned projects using the set, or part of it.
 

Always ask permission from interactivemania if you want to use an icon:
  
> On "print on demand" items such as t-shirts, postcards, mouse pads, mugs, or on any similar mass produced item that would contain an icon in a dominant way.
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Contact us at:
http://www.defaulticon.com
info@defaulticon.com
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Thessaloniki, Greece 09 Sep 2011
--------------------------------------------------------------------------------