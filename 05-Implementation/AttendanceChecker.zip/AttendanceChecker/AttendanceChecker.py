##AttendanceChecker.py authored by Faneallrich Li Yao

#This is a course requirement for CS 192 Software Engineering under the
#supervision of Asst. Prof. Ma. Rowena C. Solamo of the Department of
#Computer Science, College of Engineering, University of the Philippines,
#Diliman for the AY 2016-2017.

#Version 1.1 (Jan. 28, 2017) by Jeremy Micah Choa
# - fixed the formatting
# - added function getname() to class Classes
# - disabled delete_student(), don't need it anyway
# - changed 1st calling argument of AddClass() to be more obvious
#Version 1.0 (Jan. 18, 2017) by Faneallrich Li Yao

#File created on Jan. 18, 2017
#Developed by Team 6 Absences
#Developed for teachers and instructors everywhere (we hope)
#This is the file of the classes and methods that will be used in the
#database of Attendance Checker.

class Student:
     def __init__(self):
          self.name = ""
          self.ID = ""
     def set_ID(self,n):
          self.ID = n
     def set_name(self,n):
          self.name = n
     def getname(self):
          return self.name

class Classes:
     def __init__(self):
          self.students = []
          self.name = ""
          self.number = 0
          self.attendance = []
     def changename(self,n):
          self.name = n
     def numofsessions(self,n):
          self.number = n
     def getname(self):
          return self.name
     def getsessionnum(self):
          return self.number
     def getstudents(self):
          return self.students
     def findstudent(self,i):
          return self.students[i]
     def add_student(self,stu):
          self.students.append(stu)
          if len(self.attendance) == 0:
               self.attendance.append([0])
     #def delete_student(self,stu):
          #self.students.remove(stu)
     def getattendance(self,stu,ses):
          temp = self.students.index(stu)
          return self.attendance[ses][temp]
     def getallattendance(self):
          return self.attendance
     def setattendance(self,stu,ses):
          temp = self.students.index(stu)
          self.attendance[ses][temp] = 1

def AddClass(aList,name,sessions):
     x = Classes()
     x.changename(name)
     x.numofsessions(sessions)
     aList.append(x)

def DeleteClass(aList,cl):
     aList.remove(cl)
