from appJar import gui

#def press(rb):
#    print(app.getRadioButton("song"))

#app=gui()
#app.addRadioButton("song", "Killer Queen")
#app.addRadioButton("song", "Paradise City")

# call this function, when the RadioButton changes
#app.setRadioButtonFunction("song", press)

#app.addButton("PLAY", press)
#app.go()

def setI(btn):
    global signal
    main.disableEntry("Number of sessions:")
    signal += 1
    if signal == 2:
        signal = 0
        main.enableEntry("Number of sessions:")

def AddClass(btn):
    print(btn)
    print(main.getEntry("Name of class:"))
    tempS = 0
    tempS = main.getEntry("Number of sessions:")
    print(main.getEntry("Number of sessions:"))
    print(tempS == "")
    print(main.getEntry("Class record file:"))

def Cancel(btn):
    print(btn)
    main.hideSubWindow("up")

def Open(btn):
    main.showSubWindow("up")

signal=0
main=gui()
main.addButton("hi",Open)
main.startSubWindow("up","",True)
main.setSticky("news")
main.setStretch("both")
main.setPadding([10,5])
main.addLabelEntry("Name of class:",0,0,1)
main.addLabelEntry("Number of sessions:",1,0,1)
main.setPadding([0,0])
main.setPadding([50,0])
main.addCheckBox("Indefinite",2,0,1)
main.setPadding([0,0])
main.setCheckBoxFunction("Indefinite",setI)
main.setPadding([10,5])
main.addLabelEntry("Class record file:",3,0,1)
main.addButton("Upload Class",AddClass,4,0)
main.addButton("Cancel",Cancel,4,1)
main.stopSubWindow()
    
main.go()
