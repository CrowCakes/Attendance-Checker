##AttendanceChecker.py authored by Faneallrich Li Yao

#This is a course requirement for CS 192 Software Engineering under the
#supervision of Asst. Prof. Ma. Rowena C. Solamo of the Department of
#Computer Science, College of Engineering, University of the Philippines,
#Diliman for the AY 2016-2017.

#Version 1.3.5 (Feb. 17, 2017) by Jeremy Micah Choa
# - fixed findstudent to search by name instead of ID
# - fixed AddClass to extract comma-separated names
# - fixed AddClass to sort students alphabetically
#Version 1.3 (Feb. 10, 2017) by Jeremy Micah Choa
# - fixed AddStudent, AddClass to actually read student record file
# - disabled createClass, it was redundant
#Version 1.2 (Feb. 2, 2017) by Kenneth Velasquez
# - added functions AddStudent, createClass, AddClass
#Version 1.1 (Jan. 28, 2017) by Jeremy Micah Choa
# - fixed the formatting of this file
# - added function getname() to class Classes
# - disabled delete_student(), don't need it anyway
# - changed 1st calling argument of AddClass() to be more obvious
#Version 1.0 (Jan. 18, 2017) by Faneallrich Li Yao

#File created on Jan. 18, 2017
#Developed by Team 6 Absences
#Developed for teachers and instructors everywhere (we hope)
#This is the file of the classes and methods that will be used in the
#database of Attendance Checker.

class Student:
     
# the Student initialization function
# created Jan. 25, 2017
# - sets Student name and ID to blank
# - no input, no output
     def __init__(self):
          self.name = ""
          self.ID = ""

# set_ID
# created Jan. 25, 2017
# - sets the ID of the Student with supplied string
# - needs 1 string input, no output
     def set_ID(self,n):
          self.ID = n

# set_name
# created Jan. 25, 2017
# - sets the name of the Student with supplied string
# - needs 1 string input, no output
     def set_name(self,n):
          self.name = n

# get_name
# created Jan. 27, 2017
# - gets the name of the Student
# - no input, returns a string
     def getname(self):
          return self.name

# getID
# created Jan. 27, 2017
# - gets the ID of the Student
# - no input, returns a string
     def getID(self):
          return self.ID

class Classes:
# the Classes initialization function
# created Jan. 25, 2017
# - sets the following to blank:
# ---- list of Students in the Class
# ---- the name of the Class
# ---- the length of list "attendance"
# ---- the maximum length of list "attendance"
# ---- the list containing the attendance of each Student in each session
# ---- the list containing the start dates of each session
# - no input, no output
     def __init__(self):
          self.students = []
          self.name = ""
          self.number = 0
          self.maxnumber = 0
          self.attendance = []
          self.attDate = []

# changename
# created Jan. 25, 2017
# - sets the name of the Class
# - needs 1 string input, no output
     def changename(self,n):
          self.name = n

# numofsessions
# created Jan. 25, 2017
# - sets the maximum number of sessions in the Class
# - needs 1 integer input, no output
     def numofsessions(self,n):
          self.maxnumber = n

# getname
# created Jan. 27, 2017
# - gets the name of the Class
# - no input, returns a string
     def getname(self):
          return self.name

# getsessionnum
# created Jan. 27, 2017
# - gets the number of sessions that the Class has completed
# - no input, returns an integer
     def getsessionnum(self):
          return self.number

# getmaxsessionnum
# created Jan. 30, 2017
# - gets the maximum number of sessions that the Class can have
# - no input, returns an integer
     def getmaxsessionnum(self):
          return self.maxnumber

# getstudents
# created Jan. 30, 2017
# - gets the list of Students in the Class
# - no input, returns a list
     def getstudents(self):
          return self.students

# findstudent
# created Jan. 31, 2017
# - gets the particular Student in the Class by looking for the matching string
# - used specifically for the setPresent function in GUI.py
# - needs 1 string input, returns a Student
     def findstudent(self,i):
          for stu in self.students:
               if stu.getname() == i:
                    return stu
                    
# add_student
# created Jan. 27, 2017
# - adds a Student to the Class's list of Students
# - only called by AddClass
# - if the attendance list is empty, it appends an array with 1 element (0)
# - if not, it appends a 0 to the presumably existing initial session
# - needs 1 Student input, no output
     def add_student(self,stu):
          self.students.append(stu)
          if len(self.attendance) == 0:
               self.attendance.append([0])
          elif len(self.attendance) > 0:
               for i in self.attendance:
                    i.append(0)

# getattendance
# created Jan. 30, 2017
# - gets the attendance status of a particular student in a particular
#   session in the Class
# - returns 1 if the Student is present, 0 if absent
# - needs 2 integer inputs, returns an integer
     def getattendance(self,stu,ses):
          temp = self.students.index(stu)
          return self.attendance[ses][temp]

# getallattendance
# created Jan. 31, 2017
# - gets the entire attendance list of the Class
# - no input, returns a 2-dimensional list
     def getallattendance(self):
          return self.attendance

# setattendance
# created Jan. 31, 2017
# - sets the specified student in the specified session to present
# - needs 2 integer inputs, no output
     def setattendance(self,stu,ses):
          temp = self.students.index(stu)
          self.attendance[ses][temp] = 1

# setabsence
# created Feb. 26, 2017
# - sets the specified student in the specified session to absent
# - needs 2 integer inputs, no output
     def setabsence(self,stu,ses):
          temp = self.students.index(stu)
          self.attendance[ses][temp] = 0

# setattendance
# created Feb. 13, 2017
# - appends a new list to the attendance record
# - needs 1 list input, no output
     def extendattendance(self,new):
          self.attendance.append(new)
          # append date of function execution to self.attDate

# stringify
# created Feb. 13, 2017
# - converts given list into a string by concatenating each element in it
# - needs 1 list input, returns a string
def stringify(li):
     b = ''
     for i in li:
          b = b + str(i)
     return(b)

# AddClass
# created Feb. 1, 2017
# - generates a Class with supplied name, number of sessions, and a student
#   record file; then adds it to the supplied list
# - Students are generated with ID and name taken from the student record
#   file
# - needs 1 list, 2 strings, and 1 integer; returns nothing

# csv fields must be arranged like this: ID, Lastname, Firstname
def AddClass(aList,name,sessions,studentfile):
     sfile = open(studentfile, "r")
     x = Classes()
     x.changename(name)
     x.numofsessions(sessions)
     for line in sfile:
          Id = []
          name = []
          tok = []
          order = 0
          for i in line:
               if (i == "," and order == 0):
                    print("Found the first comma")
                    Id = stringify(tok)
                    print("Got ID#" + str(Id)) 
                    tok = []
                    order = 1     
               elif (i == "\n" or i == ""):
                    print("Found the end of the line")
                    name = stringify(tok)
                    x.add_student(MakeStudent(name, Id))
                    print("Added student " + name)
                    tok = []
                    order = 0
               else:
                    print("Found a character")
                    tok.append(i)
     #reached the end of the file
     print("Found the end of the file")
     name = stringify(tok)
     x.add_student(MakeStudent(name, Id))
     print("Added student " + name)
     tok = []
     #sort students by last name first
     x.students.sort(key=lambda x: x.name, reverse=False)
     print("Sorted class ")
     for y in x.students:
          print(y.name)
     #then add the class to the list of classes
     aList.append(x)
     sfile.close()
     

# MakeStudent
# created Feb. 1, 2017
# - generates a Student given a name and ID
# - needs 2 strings, returns a Student
def MakeStudent(name, ID):
     x = Student()
     x.set_name(name)
     x.set_ID(ID)
     return x

#def createClass(filename, classname, session):
     #info = open(filename)
     #classdata = classname+".csv"
     #defaultloc = open(classdata, 'r+')
     #for i in info.readlines():
         #defaultloc.write(i)
     #info.close()
     #AddClass(ClassesList, classname, session, defaultloc)

# DeleteClass
# created Jan. 27, 2017
# - deletes a given Class from the given list
# - needs 1 list and 1 Class, no output
def DeleteClass(aList,cl):
     aList.remove(cl)

#test = []
#S1 = MakeStudent("A", "1")
#S2 = MakeStudent("B", "2")
#AddClass(test,"test",3)
#test[0].add_student(S1)
#test[0].add_student(S2)
#ou = test[0].getallattendance()
#print(ou)
