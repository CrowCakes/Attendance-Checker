#dealing with different menus

from appJar import gui

def click(btn):
    global i
    i+=1
    i=i%2
    print(i)
    if i == 0:
        app.hideButton("Test1")
        app.showButton("Test0")
    elif i == 1:
        app.hideButton("Test0")
        app.showButton("Test1")

def click2(btn):
    global app2
    global i
    i=0
    app2=gui("","200x150")
    app2.setLocation(300,300)
    app2.addButton("Quit",quitB)
    app2.addButton("Add to i",increment)
    app2.go()

def quitB(btn):
    app2.stop()

def quitB2(btn):
    app.hideSubWindow("two")

def increment(btn):
    global i
    i+=1

def displayI():
    global i
    app.setLabel("i","i = " + str(i))

def click3(btn):
    app.showSubWindow("two")

i=0
j=0
app=gui("","150x200")
app.setFont(20)
app.setPadding([20,20])
app.addLabel("i",i)
app.registerEvent(displayI)
app.addButton("Test0",click3)
#app.addButton("Test1",click)
#app.hideButton("Test1")

app.startSubWindow("two")
app.setGeometry("400x400")
app.addButton("Quit",quitB2)
app.addButton("Add to i",increment)
app.hideSubWindow("two")
app.stopSubWindow()
app.go()
