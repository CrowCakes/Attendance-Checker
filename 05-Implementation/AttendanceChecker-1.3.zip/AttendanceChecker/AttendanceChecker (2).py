class Student:
    def __init__(self):
        self.name = ""
        self.ID = ""
    def set_ID(self,n):
        self.ID = n
    def set_name(self,n):
        self.name = n
        
				
def AddStudent(name, ID):
	x = Student()
	x.set_ID(ID)
	x.set_name(name)
	return x
    
    
class Classes:
    def __init__(self):
        self.students = []
        self.name = ""
        self.number = 0
        self.attendance = []
    def changename(self,n):
        self.name = n

    def numofsessions(self,n):
        self.number = n

    def add_student(self,stu):
        self.students.append(stu)

    def delete_student(self,stu):
        
        for i in self.students:
            if i.ID == stu.ID:
                self.students.pop(i)
                break

def AddClass(A,name,sessions,studentfile):
    x = Classes()
    x.changename(name)
    x.numofsessions(sessions)
    for line in studentfile:
            Id = 0
            name = []
            tok = []
            for i in line:
                    if (i == ","):
                            Id = int(tok)
                    elif (i == "\n")
                            name = tok
                            x.add_student(AddStudent(name, Id))
    A.append(x)
	
def DeleteClass(A, name):
	dealloc = 0
	for i in range(len(A)):
		if (A[i].name == name):
			if (i < len(A)-1):
				swap(A[i],A[i+1])
			dealloc = i
	del A[dealloc]
	
def swap(a,b):
	temp = a
	a = b
	b = temp
    
ClassesList = []

def createClass(filename, classname, session):
	if (filename[-4:] != ".csv"):
		print("file format invalid")
	else:
		info = open(filename)
		classdata = classname+".csv"
		defaultloc = open(classdata, 'r+')
		for i in info.readlines():
			defaultloc.write(i)
		info.close()
		AddClass(ClassesList, classname, session, defaultloc)
		
