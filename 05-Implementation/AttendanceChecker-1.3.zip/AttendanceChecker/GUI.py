##GUI.py authored by Jeremy Micah Choa

#This is a course requirement for CS 192 Software Engineering under the
#supervision of Asst. Prof. Ma. Rowena C. Solamo of the Department of
#Computer Science, College of Engineering, University of the Philippines,
#Diliman for the AY 2016-2017.

#Version 1.1 (Feb. 6, 2017) by Jeremy Micah Choa
# - added next Session and previous Session buttons
# - made widget alignments more uniform
# - enabled file reading
#Version 1.0 (Jan. 28, 2017) by Jeremy Micah Choa

#File created on Jan. 28, 2017
#Developed by Team 6 Absences
#Developed for teachers and instructors everywhere (we hope)
#This is the file that represents the GUI that Attendance Checker will use.

from appJar import gui
from AttendanceChecker import *
from random import randint
import os.path
import Tkinter
Tkinter.wantobjects = False

#pressUpload
#created Jan. 28, 2017
# - adds a class to the list of classes, then calls updateClassNames
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Upload Class, no return values
# - needs the following to work:
# ----- the appJar library
# ----- updateClassNames and its requirements
# ----- the file AttendanceChecker.py
def pressUpload(btn):
     print(btn)
     main.showSubWindow("up")

#setI
#created Jan. 31, 2017
# - disables entry for "Number of Sessions:" in the Upload Class subwindow
#   when the "Indefinite" option is checked
# - needs the following to work:
# ----- the appJar library
def setI(btn):
    global signal
    main.disableEntry("Number of sessions:")
    signal += 1
    if signal == 2:
        signal = 0
        main.enableEntry("Number of sessions:")

#Cancel
#created Jan. 31, 2017
# - hides the Upload Class subwindow
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Cancel, no return values
# - needs the following to work:
# ----- the appJar library
def Cancel(btn):
     print(btn)
     main.clearAllEntries()
     main.hideSubWindow("up")

#doUpload
#created Jan. 31, 2017
# - retrieves the user-inputted data from the Upload Class subwindow,
#   then passes it to the AddClass function
# - indefinite number of sessions is -1
# - lots of error checking involved
# - upon successful uploading of class or cancellation, the entry fields are
#   cleared and the Upload Class subwindow is closed
# - also upon successful uploading of class, updateClassNames is called
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Upload Class, no return values
# - needs the following to work:
# ----- the appJar library
# ----- the file AttendanceChecker.py for function AddClass
def doUpload(btn):
     tempN = main.getEntry("Name of class:")
     tempS = main.getCheckBox("Indefinite")
     tempF = main.getEntry("Class record file:")
     if tempN == "":
          main.errorBox("Error","Please enter a name for your class.")
     else:
          if tempS == False:
               tempS = main.getEntry("Number of sessions:")
               if (tempS == "" or tempS.isdigit() == False):
                    main.errorBox("Error","Please enter how many sessions your\nclass will run for.")
               elif tempS <= 0:
                    main.errorBox("Error","Please enter a positive value for your sessions.")
               else:
                    if tempF == "":
                         main.errorBox("Error","Please enter a file of your class record.")
                    else:
                         if os.path.isfile(tempF) == False:
                              main.errorBox("Error","That file doesn't exist.")
                         elif (tempF[-4:] != ".csv"):
                              main.errorBox("Error","The file must be a .csv file.")
                         else:
                              AddClass(classes,tempN,tempS,tempF)
                              #AddClass(classes,tempN,tempS)
                              #temp = Student()
                              #temp.set_ID("1")
                              #temp.set_name("A")
                              #classes[-1].add_student(temp)
                              main.infoBox("success","Your class has been uploaded!")
                              main.clearAllEntries()
                              main.hideSubWindow("up")
                              main.showButton("View Class")
                              updateClassNames()
          else:
               tempS = -1
               if tempF == "":
                    main.errorBox("Error","Please enter a valid file of your class record.")
               else:
                    if os.path.isfile(tempF) == False:
                         main.errorBox("Error","That file doesn't exist.")
                    elif (tempF[-4:] != ".csv"):
                         main.errorBox("Error","The file must be a .csv file.")
                    else:
                         AddClass(classes,tempN,tempS,tempF)
                         #AddClass(classes,tempN,tempS)
                         #temp = Student()
                         #temp.set_ID("1")
                         #temp.set_name("A")
                         #classes[-1].add_student(temp)
                         main.infoBox("success","Your class has been uploaded!")
                         main.clearAllEntries()
                         main.hideSubWindow("up")
                         main.showButton("View Class")
                         updateClassNames()

#pressDelete
#created Jan. 30, 2017
# - deletes the user-selected class from the list of classes,
#   then calls updateClassNames
# - only callable/button only appears when a class exists
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Delete Class, no return values
# - needs the following to work:
# ----- the appJar library
# ----- updateClassNames and its requirements
# ----- the file AttendanceChecker.py
def pressDelete(btn):
     print(btn)
     print("deleting class " + str(main.getListItems("classes")))
     temp = classesName.index(main.getListItems("classes")[0])
     DeleteClass(classes,classes[temp])
     updateClassNames()
     print("done deleting")
     print("classes -> " + str(main.getListItems("classData")))
     main.updateListItems("classData", main.getListItems("classData"))

#toggleButtons
#created Jan. 31, 2017
# - hides the View Class and Delete Class button whenever there are
#   0 classes or
#   when the View Class list box is the active list box
# - 1 arg of type string (lb) automatically supplied by the list box,
#   no return values
# - needs the following to work:
# ----- the appJar library
# ----- the View Class and Delete Class buttons
def toggleButtons(lb):
     global currentSession
     global maxSession
     print(lb)
     if (lb == "classData" and len(main.getAllListItems("classData")) > 0):
          main.hideButton("Delete")
          main.hideButton("View Class")
          main.showButton("Present!")
          if currentSession > 0:
               main.showButton("Previous Session")
          if currentSession < maxSession:
               main.showButton("Next Session")
     elif (lb == "classes" and len(classes) > 0):
          main.showButton("View Class")
          main.showButton("Delete")
          main.hideButton("Present!")
          main.hideButton("Previous Session")
          main.hideButton("Next Session")
     elif lb == "classes":
          main.hideButton("Present!")
          main.hideButton("Previous Session")
          main.hideButton("Previous Session")

#pressView
#created Jan. 30, 2017
# - displays the user-selected class's details, including students and their
#   current attendance status in the latest class session
# - hides the Delete and View Class buttons, shows the Present! button
# - 1 arg of type string (btn) automatically supplied by the Button for
#   View Class, no return values
# - needs the following to work:
# ----- the appJar library
# ----- the file AttendanceChecker.py
def pressView(btn):
     print(btn)
     #main.showSubWindow("view")
     global classDataDisplay
     global studentsNames
     global currentSession
     global maxSession
     print("selected " + str(main.getListItems("classes")))
     if len(classes) > 0:
          # temp is the list of things to be displayed
          # tempS is the list of students to be displayed, and is needed to make
          #    setPresent() easier
          temp = []
          tempS = []
          # get the index of the class being viewed
          index = classesName.index(main.getListItems("classes")[0])
          # save it to global variable
          classDataDisplay = index
          print("classes index -> " + str(classDataDisplay))
          # get class name
          temp.append(classes[index].getname())
          # get class num of sessions
          if classes[index].getmaxsessionnum() == -1:
               temp.append("This class will last indefinitely")
          else:
               temp.append("Running for " + str(classes[index].getmaxsessionnum()) + " sessions")
          temp.append("")
          # set # of current session (i.e. the latest one)
          #    being viewed, zero-indexing already
          currentSession = classes[index].getsessionnum()
          # get max number of sessions for the class being viewed, 0-indexing
          maxSession = int(classes[index].getmaxsessionnum()) - 1
          print("max sessions for this class -> " + str(maxSession))
          temp.append("Session " + str(currentSession + 1))
          # get list of present and absent students in latest session
          temp.append("Present:")
          for stud in classes[index].getstudents():
               if classes[index].getattendance(stud,-1) == 1:
                    temp.append(stud.getname())
                    tempS.append(stud.getname())
          temp.append("Absent:")
          for stud in classes[index].getstudents():
               if classes[index].getattendance(stud,-1) == 0:
                    temp.append(stud.getname())
                    tempS.append(stud.getname())
          # display the class details
          main.updateListItems("classData",temp)
          print("current session -> " + str(currentSession))
          # set list of students in the class being viewed
          studentsNames = tempS
          main.hideButton("Delete")
          main.hideButton("View Class")
          main.showButton("Present!")
          main.showButton("Previous Session")
          main.showButton("Next Session")

#refreshView
#created Jan. 31, 2017
# - functionally identical to pressView, to be called before ending
#   a successful setPresent
# - also called after switching between class sessions
# - no calling arguments, no return values
# - needs the following to work:
# ----- the appJar library
# ----- the file AttendanceChecker.py
def refreshView():
     global classDataDisplay
     global studentsNames
     global currentSession
     print("refreshing")
     if len(classes) > 0:
          temp = []
          tempS = []
          print("classes index -> " + str(classDataDisplay))
          temp.append(classes[classDataDisplay].getname())
          if classes[classDataDisplay].getmaxsessionnum() == -1:
               temp.append("This class will last indefinitely")
          else:
               temp.append("Running for " + str(classes[classDataDisplay].getmaxsessionnum()) + " sessions")
          temp.append("")
          temp.append("Session " + str(currentSession + 1))
          temp.append("Present:")
          for stud in classes[classDataDisplay].getstudents():
               if classes[classDataDisplay].getattendance(stud,currentSession) == 1:
                    temp.append(stud.getname())
                    tempS.append(stud.getname())
          temp.append("Absent:")
          for stud in classes[classDataDisplay].getstudents():
               if classes[classDataDisplay].getattendance(stud,currentSession) == 0:
                    temp.append(stud.getname())
                    tempS.append(stud.getname())
          main.updateListItems("classData",temp)
          studentsNames = tempS
          main.hideButton("Delete")
          main.hideButton("View Class")
          main.showButton("Present!")
          main.showButton("Previous Session")
          main.showButton("Next Session")

#setPresent
#created Jan. 31, 2017
# - sets the selected student's attendance to present, then updates
#   the class data being displayed
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Present!, no return values
# - needs the following to work:
# ----- the appJar library
# ----- the file AttendanceChecker.py
def setPresent(btn):
     global classDataDisplay
     global studentsNames
     global currentSession
     print(btn)
     print("selected " + str(main.getListItems("classData")))
     if main.getListItems("classData")[0] in studentsNames:
          tempSN = main.getListItems("classData")[0]
          print("student's name -> " + str(tempSN))
          tempI = studentsNames.index(tempSN)
          print("student's ID -> " + str(tempI))
          tempS = classes[classDataDisplay].findstudent(tempI)
          classes[classDataDisplay].setattendance(tempS,-1)
          refreshView()

#prevSession
#created Feb. 7, 2017
# - displays the session before the one being viewed
# - will refresh the view after adjusting the # of the session being viewed
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Prev Session, no return values
# - needs the following to work:
# ----- the appJar library
def prevSession(btn):
     global currentSession
     print(btn)
     if currentSession != 0:
          currentSession -= 1
          refreshView()
     else:
          print("can't go any further back")
          

#nextSession
#created Feb. 7, 2017
# - displays the session after the one being viewed
# - creates a new record of attendance for the next session if the current
#   one being viewed is the latest session
# - will refresh the view after adjusting the # of the session being viewed
# - 1 arg of type string (btn) automatically supplied by the Button for
#   Next Session, no return values
# - needs the following to work:
# ----- the appJar library
def nextSession(btn):
     global currentSession
     global classDataDisplay
     global maxSession
     print(btn)
     if (currentSession < maxSession) or (maxSession == -1):
          print("currentSession was " + str(currentSession))
          print("gonna add 1 to currentSession")
          currentSession += 1
          print("currentSession is " + str(currentSession))
          if len(classes[classDataDisplay].getallattendance()) <= maxSession:
               print("add another list to the attendance record")
               b = []
               for i in range(len(classes[classDataDisplay].getallattendance()[-1])):
                    b.append(0)
               classes[classDataDisplay].extendattendance(b)
          refreshView()
     else:
          print("can't go further forward")
         
#uploadBtn
#created Jan. 28, 2017
# - generates the button for "Upload Class"
# - see pressUpload for the effect of pressing the button
# - no args, no return values
# - needs the following to work:
# ----- upload.gif, the icon for Upload Class
# ----- the appJar library
def uploadBtn():
     main.setSticky("nw")
     main.setPadding([10,5])
     main.addButton("Upload",pressUpload,0,0)
     main.setButtonImage("Upload","upload.gif")
     main.setSticky("")
     main.setPadding([0,0])

#viewBtn
#created Jan. 30, 2017
# - generates the button for "View Class"
# - see pressView for the effect of pressing the button
# - no args, no return values
# - needs the following to work:
# ----- upload.gif, the icon for Upload Class
# ----- the appJar library
def viewBtn():
     main.setSticky("nw")
     main.setPadding([5,0])
     main.addButton("View Class",pressView,0,1)
     #main.setButtonImage("Upload","upload.gif")
     main.setSticky("")
     main.hideButton("View Class")
     main.setPadding([0,0])

#deleteBtn
#created Jan. 30, 2017
# - generates the button for "Delete Class"
# - see pressDelete for the effect of pressing the button
# - no args, no return values
# - needs the following to work:
# ----- delete.gif, the icon for Delete Class
# ----- the appJar library
def deleteBtn():
     main.setPadding([10,00])
     main.setSticky("nw")
     main.addButton("Delete",pressDelete,0,2)
     main.setButtonImage("Delete","delete.gif")
     main.setSticky("")
     main.hideButton("Delete")
     main.setPadding([0,0])

#checkPresent
#created Jan. 31, 2017
# - generates the button for "Present!"
# - see setPresent for the effect of pressing the button
# - no args, no return values
# - needs the following to work:
# ----- the appJar library
def checkPresent():
     main.setPadding([5,00])
     main.addButton("Present!",setPresent,2,2)
     #main.setButtonImage("Delete","delete.gif")
     main.hideButton("Present!")
     main.setPadding([0,0])

#sessionButton
#created Feb. 7, 2017
# - generates the button for "Next Session" and "Previous Session"
# - see  for the effect of pressing the button
# - no args, no return values
# - needs the following to work:
# ----- the appJar library
def sessionButton():
     main.setPadding([10,00])
     main.addButton("Previous Session",prevSession,2,1)
     main.hideButton("Previous Session")
     main.setPadding([0,0])

     main.setPadding([10,00])
     main.addButton("Next Session",nextSession,2,3)
     main.hideButton("Next Session")
     main.setPadding([0,0])

#menu0_display
#created Jan. 28, 2017
# - generates the subcontents of the main page
# - no args, no return values
# - needs the following to work:
# ----- the appJar library
def menu0_display():
     main.setPadding([0,10])
     main.setSticky("nw")
     main.addLabel("label00","You don't have any classes!\nMake a class by clicking the Upload Class button!",0,4)
     #main.addImage("label00","zeroclasses.gif",0,1)
     main.setSticky("")

     main.startLabelFrame("Your Classes")
     #main.setPadding([20,18])
     main.setSticky("nw")
     main.addListBox("classes",classesName,1,0)
     main.setListBoxHeight("classes",25)
     main.setSticky("")
     main.stopLabelFrame()

     main.setSticky("news")
     main.addListBox("classData",classesName,1,1,3)
     main.setListBoxHeight("classData",25)
     main.setListBoxWidth("classData",40)
     main.setSticky("")

     main.addLabel("label01","Attendance Checker v1.0",2,4)

     main.setListBoxFunction("classData",toggleButtons)
     main.setListBoxFunction("classes",toggleButtons)
     
     if len(classes) > 0:
          main.hideLabel("label00")
          main.showButton("Delete")
          main.showButton("View Class")

#menu0
#created Jan. 28, 2017
# - generates the main page in the correct position relative to
#   the background image
# - no args, no return values
# - see uploadBtn and menu0_display for this function's requirements
def menu0():
     uploadBtn()
     deleteBtn()
     viewBtn()
     checkPresent()
     sessionButton()
     menu0_display()
     updateClassNames()

#upMenu
#created Jan. 31, 2017
# - generates the Upload Class subwindow, initially hidden
# - no args, no return values
# - needs the following to work:
# ----- the appJar library
# ----- functions setI, doUpload, and Cancel
def upMenu():
     main.startSubWindow("up","",True)
     main.setSticky("news")
     main.setStretch("both")
     
     main.setPadding([10,5])
     main.addLabelEntry("Name of class:",0,0,1)
     
     main.addLabelEntry("Number of sessions:",1,0,1)
     main.setPadding([0,0])
     
     main.setPadding([50,0])
     main.addCheckBox("Indefinite",2,0,1)
     main.setPadding([0,0])
     main.setCheckBoxFunction("Indefinite",setI)
     
     main.setPadding([10,5])
     main.addLabelEntry("Class record file:",3,0,1)
     
     main.addButton("Upload Class",doUpload,4,0)
     main.addButton("Cancel",Cancel,4,1)
     main.stopSubWindow()


#upMenu
#created Feb. 7, 2017
# - generates the View Class subwindow, initially hidden
# - no args, no return values
# - needs the following to work:
# ----- the appJar library
# ----- functions 
#def viewMenu():
     #main.startSubWindow("view","",True)
     #main.setSticky("nw")
     #main.addListBox("classData",classesName)
     #main.setListBoxHeight("classData",25)
     #main.setListBoxWidth("classData",27)
     #main.setSticky("")
     #main.setListBoxFunction("classData",toggleButtons)
     #checkPresent()
     #main.stopSubWindow()
    
#updateClassNames
#created Jan. 28, 2017
# - flush the list of classes' names, then fill with the names of all classes
#   and then update the GUI
# - to be used as argument for registerEvent()
# - no calling args, no return values
# - needs the following:
# ----- the file AttendanceChecker.py
# ----- the appJar library
# ----- the list of classes and a list for their names
def updateClassNames():
     global classes
     global classesName
     del classesName[:]
     if len(classes) > 0:
          for name in classes:
               classesName.append(name.getname())
     main.updateListItems("classes",classesName)
     print("names of existing classes -> " + str(classesName))
     if len(classes) == 0:
          main.hideButton("Delete")
          main.hideButton("View Class")
          main.showLabel("label00")
     else:
          main.hideLabel("label00")
          main.showButton("Delete")
          main.showButton("View Class")

#checkStop
#created Jan. 31, 2017
# - displays a prompt when the user tries to quit the application
# - no calling args, returns True if Yes was answered, otherwise False
# - needs the following:
# ----- the appJar library
def checkStop():
     global classes
     temp = main.yesNoBox("quit", "Are you sure you want to quit?")
     if temp == True:
          f = open("savefile.txt","w")
          for item in classes:
               f.write(item.getname())
               f.write("\n")
               f.write(str(item.getmaxsessionnum()))
               f.write("\n")
               for stud in item.getstudents():
                    f.write(stud.getname())
                    f.write(" ")
                    f.write(stud.getID())
                    f.write("\n")
               for record in item.getallattendance():
                    for entry in range(len(record)):
                         f.write(str(record[entry]))
                         f.write(" ")
                    f.write("\n")
          f.close()
     return temp
         
#--------------------------------------------------------------#
#indefinite/class length entry
signal = 0
#zero-indexed
currentSession = 0
#not zero-indexed
maxSession = 0
#index of the class being viewed
classDataDisplay = 0
#list of classes
classes = []
#AddClass(classes,"Test",1)
#list of the names of classes
classesName = []
#list of students in the class being viewed
studentsNames = []

#main = gui("Attendance Checker","800x600")
main = gui("Attendance Checker","1245x776")
main.setFont(14,"Berlin Sans FB")
#main.setBgImage("background.gif")

menu0()
upMenu()
#viewMenu()
main.setStopFunction(checkStop)

    
main.go()
